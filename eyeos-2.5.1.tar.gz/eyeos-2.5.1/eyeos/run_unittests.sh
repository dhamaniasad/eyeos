clear
phpunit --colors --bootstrap ./tests/init.php ${1} ${2} ${3} ${4} ./tests
